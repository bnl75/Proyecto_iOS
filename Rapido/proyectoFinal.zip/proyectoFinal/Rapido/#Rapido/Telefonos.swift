//
//  Telefonos.swift
//  #Rapido
//
//  Created by Laboratorio UNAM-Apple 01 on 08/10/19.
//  Copyright © 2019 ari. All rights reserved.
//

import Foundation
import UIKit

struct Telefonos {
    
    var telefono : String
    
    static var listTelefonos : [Telefonos] = [
        
        Telefonos.init(telefono: "5587235630"),
        Telefonos.init(telefono: "63234506")
    
    ]
    
}


